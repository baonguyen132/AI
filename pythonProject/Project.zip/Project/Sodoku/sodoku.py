from Project.Sodoku.create_soroku_interface import create_soroku_interface

if __name__ == '__main__':
    create_soroku_interface()
